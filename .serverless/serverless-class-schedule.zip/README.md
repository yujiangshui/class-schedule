# class-schedule

My class schedule tool for English learning.

## Installing

You can just open online version http://class-schedule.harryyu.me/ and use it.

Or you can clone this code and deploy to your server. This app has zero dependence it just needs a static server.

## Usage 

You can edit time by setting icon which on the top. You can edit the cell text by clicking the cell item. You will hear a voice when reaching some time point. That's it, have fun.
